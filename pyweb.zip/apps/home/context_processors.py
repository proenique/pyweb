from apps.base.models import SiteInfo
from django.shortcuts import get_object_or_404

def engine(request):
    site = get_object_or_404(SiteInfo, pk=1)
    context = {
        'name':site.name,
        'logo':site.logo.url,
        'members':site.members.all,
        'about':site.about,
        'moto':site.moto,
        'vision':site.vision,
        'mission':site.mission,
        'info_email':site.info_email,
        'sales_email':site.sales_email,
        'call_number':site.call_number,
        'whatsapp_number':site.whatsapp_number,
        'facebook':site.facebook,
        'twiter':site.twiter,
        'instagram':site.instagram,
    }

    return context