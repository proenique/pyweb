#from django.contrib import messages 
from django.shortcuts import render, get_object_or_404, get_list_or_404
from .models import Service, Plan
# Create your views here.



def service_view(request, slug):
    template_name = 'service.html'
    service = get_object_or_404(Service, slug=slug)
    plans = get_list_or_404(Plan, service=service)
    context = {
        'page_title':service.name,
        'service':service,
        'plans':plans,
    }
    return render(request, template_name, context)
    