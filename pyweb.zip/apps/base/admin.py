from django.contrib import admin
from .models import SiteInfo
# Register your models here.


admin.site.register(SiteInfo)
